<?php 
return [
'Codename' 			=> '7010',
'Version' 			=> '7.1',
'Build' 			=> '2021-01-25' ,
'Repository'		=> 'https://sximo.net/'
];
